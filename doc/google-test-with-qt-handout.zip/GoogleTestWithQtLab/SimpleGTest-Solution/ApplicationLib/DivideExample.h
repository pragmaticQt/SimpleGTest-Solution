#ifndef DIVIDEEXAMPLE_H
#define DIVIDEEXAMPLE_H

#include "ApplicationLibDecl.h"

class APPLICATIONLIB_EXPORT DivideExample
{
public:
    double divide(double dividend, double divisor);
};

#endif // DIVIDEEXAMPLE_H
