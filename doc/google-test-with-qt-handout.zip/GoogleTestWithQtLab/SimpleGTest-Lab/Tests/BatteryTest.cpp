#include "Battery.h"

#include "QtTypePrinters.h"

#include "Mocks/MockBatteryCell.h"

#include <gtest/gtest.h>

using namespace ::testing;

class BatteryTest : public Test
{
public:
    BatteryTest() :
        m_battery(m_batteryCellOne, m_batteryCellTwo)
    {
    }

protected:
    //Dependancies
    NiceMock<MockBatteryCell> m_batteryCellOne;
    NiceMock<MockBatteryCell> m_batteryCellTwo;

    //Class Under Test
    Battery m_battery;
};

