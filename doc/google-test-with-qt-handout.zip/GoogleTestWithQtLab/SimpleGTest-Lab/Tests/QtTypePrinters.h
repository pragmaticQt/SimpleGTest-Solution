#ifndef TESTHELPERS_H
#define TESTHELPERS_H

#include <QString>

#include <ostream>

QT_BEGIN_NAMESPACE
inline void PrintTo(const QString &qString, ::std::ostream *os)
{
    *os << qString.toStdString();
}
QT_END_NAMESPACE

#endif // TESTHELPERS_H
