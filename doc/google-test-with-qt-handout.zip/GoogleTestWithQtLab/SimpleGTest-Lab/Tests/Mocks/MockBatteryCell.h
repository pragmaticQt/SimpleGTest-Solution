#ifndef MOCKBATTERYCELL_H
#define MOCKBATTERYCELL_H

#include "IBatteryCell.h"

#include <gmock/gmock.h>

class MockBatteryCell : public IBatteryCell
{
    Q_OBJECT
public:
};

#endif // MOCKBATTERYCELL_H
