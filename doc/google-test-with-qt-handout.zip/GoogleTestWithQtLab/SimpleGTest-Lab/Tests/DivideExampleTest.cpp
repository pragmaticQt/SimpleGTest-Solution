#include "DivideExample.h"

#include <gtest/gtest.h>

using namespace ::testing;

class DivideExampleTest : public Test
{
protected:
    DivideExample m_divideExample;
};

//TODO Add test functions for DivideExample::divide

