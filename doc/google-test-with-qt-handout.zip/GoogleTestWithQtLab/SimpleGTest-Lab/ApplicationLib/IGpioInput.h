#ifndef IGPIOINPUT_H
#define IGPIOINPUT_H

#include "ApplicationLibDecl.h"

#include <QObject>

class APPLICATIONLIB_EXPORT IGpioInput : public QObject
{
    Q_OBJECT
};

#endif // IGPIOINPUT_H
