#include "Battery.h"

Battery::Battery(IBatteryCell &cellOne, IBatteryCell &cellTwo) :
    m_cellOne(cellOne),
    m_cellTwo(cellTwo)
{
}
