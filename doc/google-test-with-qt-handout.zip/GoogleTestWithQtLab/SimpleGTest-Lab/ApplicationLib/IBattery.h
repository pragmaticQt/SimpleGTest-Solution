#ifndef IBATTERY_H
#define IBATTERY_H

#include "ApplicationLibDecl.h"

#include <QObject>

class APPLICATIONLIB_EXPORT IBattery : public QObject
{
    Q_OBJECT
};

#endif // IBATTERY_H
