#ifndef ISPI_H
#define ISPI_H

#include "ApplicationLibDecl.h"

#include <QObject>

class APPLICATIONLIB_EXPORT ISpi : public QObject
{
    Q_OBJECT
};

#endif // ISPI_H
