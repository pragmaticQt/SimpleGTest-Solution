#ifndef IBATTERYCELL_H
#define IBATTERYCELL_H

#include "ApplicationLibDecl.h"

#include <QObject>

class APPLICATIONLIB_EXPORT IBatteryCell : public QObject
{
    Q_OBJECT
};

#endif // IBATTERYCELL_H
