#ifndef BATTERY_H
#define BATTERY_H

#include "ApplicationLibDecl.h"

#include "IBattery.h"
#include "IBatteryCell.h"

#include <QList>

class APPLICATIONLIB_EXPORT Battery : public IBattery
{
    Q_OBJECT
public:
    Battery(IBatteryCell &cellOne, IBatteryCell &cellTwo);

    //TODO Add a chargePercent function that averages the two cells
    //If either cell returns 0 chargePercent shall return 0
    //Emit a signal when either cell changes

private:
    IBatteryCell &m_cellOne;
    IBatteryCell &m_cellTwo;
};

#endif // BATTERY_H
