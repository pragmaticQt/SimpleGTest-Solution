#include "Spi.h"

Spi::Spi()
{
}
