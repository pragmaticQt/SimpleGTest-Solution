#include "GpioInput.h"

GpioInput::GpioInput()
{
}
