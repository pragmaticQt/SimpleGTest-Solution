#ifndef DIVIDEEXAMPLE_H
#define DIVIDEEXAMPLE_H

#include "ApplicationLibDecl.h"

class APPLICATIONLIB_EXPORT DivideExample
{
    //TODO Add divide function via TDD
    //Throw std::invalid_exception("divisor cannot be zero") on divide by zero
};

#endif // DIVIDEEXAMPLE_H
